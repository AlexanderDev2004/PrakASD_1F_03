package Kuis2_02_Alexander_1F;

public class pembeli03 {
    public String kodepesanan;
    public String namaPembeli;
    public String phoneNumber;

    public pembeli03(String kodepesanan, String namaPembeli, String phoneNumber) {
        this.kodepesanan = kodepesanan;
        this.namaPembeli = namaPembeli;
        this.phoneNumber = phoneNumber;
    }
}
