package Kuis2_02_Alexander_1F;

public class pesanan03 {
    public String kodePesanan;
    public String namaPesanan;
    public int harga;

    public pesanan03(String kodePesanan, String namaPesanan, int harga) {
        this.kodePesanan = kodePesanan;
        this.namaPesanan = namaPesanan;
        this.harga = harga;
    }
}
