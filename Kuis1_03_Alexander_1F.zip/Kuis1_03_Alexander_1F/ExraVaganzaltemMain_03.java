package Kuis1_03_Alexander_1F;

public class ExraVaganzaltemMain_03 {

  
    public static void main(String[] args) {

        System.out.println("================================");
        System.out.println("Selamat datang di Apotek");
        System.out.println("Silahkan pilih menu anda");
        System.out.println("================================");
        System.out.println("1. Masukan Data Obat ");
        System.out.println("2. Tunjukan Harga Obat  ");
        System.out.println("3. Perbarui Harga  ");
        System.out.println("4. Jual  ");
        System.out.println("5. Exit Progrma  ");
        int menu;
        switch (menu) {
            case 1:
                
                break;

            case 2:
            ExraVaganzaltem_03.TampilExraVaganzaltem(null, null, menu, menu);
                break;
            case 3:
                
                break;
            case 4 :

                break;
            case 5:
                System.out.print("=> Konfirmasi Keluar y/n : ");
                Object input;
                final char exit = ( (Object) input).nextLine().charAt(0);

                if ((exit == 'n') || (exit == 'N')) {
                    break;
                } else if ((exit == 'y') || (exit == 'Y')) {
                    System.out.println("Terimakasih Telah Menggunakan Aplikasi Ini");
                    System.exit(0);
                }

                // break;

            default:
                System.out.println("Pilihan Tidak Tersedia");
        }

    }
}
